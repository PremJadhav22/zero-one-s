/*
#[test_only]
module neuraltrust_sbt::neuraltrust_sbt_tests;
// uncomment this line to import the module
// use neuraltrust_sbt::neuraltrust_sbt;

const ENotImplemented: u64 = 0;

#[test]
fun test_neuraltrust_sbt() {
    // pass
}

#[test, expected_failure(abort_code = ::neuraltrust_sbt::neuraltrust_sbt_tests::ENotImplemented)]
fun test_neuraltrust_sbt_fail() {
    abort ENotImplemented
}
*/
