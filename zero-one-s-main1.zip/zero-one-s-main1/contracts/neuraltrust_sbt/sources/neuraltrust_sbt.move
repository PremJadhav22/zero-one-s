module neuraltrust_sbt::soulbound_token {
    use sui::tx_context::{Self, TxContext};
    use sui::object::{Self, UID};
    use sui::transfer;
    use std::string;

    public struct SoulboundNFT has key, store {
        id: UID,
        score: u64,
        owner: address,
        metadata: string::String
    }

    public entry fun mint(
        score: u64,
        metadata: vector<u8>,
        ctx: &mut TxContext
    ) {
        let sender = tx_context::sender(ctx);
        let nft = SoulboundNFT {
            id: object::new(ctx),
            score: score,
            owner: sender,
            metadata: string::utf8(metadata)
        };
        transfer::transfer(nft, sender);
    }
}